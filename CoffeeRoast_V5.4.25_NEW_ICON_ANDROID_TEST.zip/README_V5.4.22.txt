CoffeeRoast V5.4.22
- Root cause fix: attach WebChromeClient to WebView so JavaScript alert()/confirm() dialogs work.
- This allows delete confirmation to appear and deletion code to continue after confirmation.
- Updated visible version and Android bridge ping to V5.4.22.
