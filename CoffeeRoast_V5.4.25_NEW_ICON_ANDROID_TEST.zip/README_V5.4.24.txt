CoffeeRoast V5.4.24

Based on verified stable V5.4.23.
Fixes:
1. A newly started roast can directly edit bean temperature / power / fan without pressing 修正.
2. Starting a new roast clears any stale loaded-history ID so saving appends a new history batch instead of overwriting an older batch.

Preserved from V5.4.23: WebChromeClient batch deletion, JSON backup/list/restore, selected-history CSV bean/date filename fix, permanent-keystore update compatibility, curve/share and existing roasting functions.
