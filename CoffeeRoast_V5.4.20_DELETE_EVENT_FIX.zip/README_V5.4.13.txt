CoffeeRoast V5.4.13
- 修正更新後按「開啟」時可能回到先前 Android 另存新檔畫面的問題。
- 移除已廢棄的 ACTION_CREATE_DOCUMENT / saveTextFile 備份路徑，避免啟動時殘留舊檔案建立流程。
- MainActivity 設為 singleTask 並在從啟動器開啟時清理舊 task 上層畫面。
- 歷史資料備份仍使用一鍵寫入 Download/CoffeeRoast；還原才開啟 JSON 選檔器。
- versionCode 5413 / versionName 5.4.13。
