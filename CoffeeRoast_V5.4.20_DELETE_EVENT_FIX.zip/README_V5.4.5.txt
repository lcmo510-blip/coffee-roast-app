CoffeeRoast V5.4.5 - Back / Exit Fix

Changes from V5.4.4:
1. Android Back no longer directly exits the Activity.
2. Back closes an open modal first.
3. Back on the roasting page returns to Basic Data.
4. Back at the top level opens the existing exit confirmation dialog.
5. Exit confirmation can call AndroidApp.exitApp() for a real Activity exit.
6. Keeps V5.4.4 bottom navigation-bar inset protection.
7. Save/share native functions are still intentionally not restored in this diagnostic step.
