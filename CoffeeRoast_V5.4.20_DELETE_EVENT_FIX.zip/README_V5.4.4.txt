CoffeeRoast V5.4.4 diagnostic build

Changes from V5.4.3:
1. Add a minimal AndroidApp JavaScript bridge with only ping().
2. Protect the bottom Android navigation-bar inset so WebView content is not covered.
3. Keep the working V5.4.3 WebView/index.html baseline unchanged otherwise.

Purpose: determine whether simply adding AndroidApp bridge causes the startup crash before restoring save/share/exit functions.
