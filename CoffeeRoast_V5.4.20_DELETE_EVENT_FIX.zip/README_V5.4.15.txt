CoffeeRoast V5.4.15

- Fix restore picker on Samsung/Android: open all document types so JSON backups in Downloads/CoffeeRoast are visible.
- Selected file is still parsed and validated as JSON before restoring roast history.
- Preserve V5.4.14 history backup behavior and all existing functions.
