V5.4.3 WebView startup diagnostic build
Only WebView + index.html loading is enabled. Android JS bridge, file chooser, save/share, exit bridge, and system-bar startup code are intentionally disabled.
