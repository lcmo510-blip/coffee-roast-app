CoffeeRoast V5.4.12
- 備份資料：只備份已儲存的歷史烘焙批次，JSON 自動存入 Download/CoffeeRoast。
- 還原資料：選擇 JSON 歷史備份後還原歷史批次。
- 匯出 CSV：自動存入 Download/CoffeeRoast。
- 保留 V5.4.11 其他功能。
