CoffeeRoast V5.4.9

修正：
1. 歷史資料「帶入資料」每次開啟時重新同步清單，帶入後重新渲染並切換到對應頁面。
2. 儲存曲線改為 Android Bridge 同步回傳 OK/ERR，避免按鈕永久停在「儲存中…」。
3. 分享曲線改為 Android Bridge 同步回傳 OK/ERR，分享視窗送出後按鈕立即恢復。
4. 版本顯示、Bridge ping、versionCode/versionName 同步至 V5.4.9 / 549。
5. 保留 V5.4.8 已驗證的返回鍵、退出、底部避讓、烘焙紀錄與曲線功能。
