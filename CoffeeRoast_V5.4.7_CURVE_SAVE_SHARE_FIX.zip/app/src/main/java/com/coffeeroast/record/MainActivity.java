package com.coffeeroast.record;

import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.os.Build;
import android.os.Bundle;
import android.window.OnBackInvokedDispatcher;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // V5.4.4: keep app content out of Android system bars.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(true);
        }

        setContentView(R.layout.activity_main);

        final View root = findViewById(R.id.root);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int bottom;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                bottom = insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
            } else {
                bottom = insets.getSystemWindowInsetBottom();
            }
            // Top is already correct in V5.4.3; only protect the bottom navigation area.
            v.setPadding(0, 0, 0, bottom);
            return insets;
        });
        root.requestApplyInsets();

        webView = findViewById(R.id.webview);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);

        // V5.4.7: native bridge includes exit + curve image save/share.
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidApp");

        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/index.html");

        // V5.4.6: Android 13+ predictive-back must be intercepted explicitly.
        // Without this callback, some Samsung/Android versions can finish the Activity
        // before the legacy onBackPressed() path reaches the WebView.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                () -> dispatchBackToWebView()
            );
        }
    }

    private void dispatchBackToWebView() {
        if (webView != null) {
            webView.evaluateJavascript(
                "if(window.handleAndroidBack){window.handleAndroidBack();}else if(window.requestAppExit){window.requestAppExit();}",
                null
            );
        }
    }

    public class AndroidBridge {
        @JavascriptInterface
        public String ping() {
            return "V5.4.5";
        }

        @JavascriptInterface
        public void exitApp() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    finishAndRemoveTask();
                } else {
                    finish();
                }
            });
        }

        @JavascriptInterface
        public void saveImage(String filename, String dataUrl) {
            runOnUiThread(() -> {
                try {
                    Uri uri = writePngToPictures(filename, dataUrl, "CoffeeRoast");
                    showJsMessage("✅ 曲線圖片已儲存到相簿 CoffeeRoast。\n" + filename);
                } catch (Exception e) {
                    showJsMessage("❌ 儲存曲線圖片失敗：" + safeMessage(e));
                }
            });
        }

        @JavascriptInterface
        public void shareImage(String filename, String dataUrl, String text) {
            runOnUiThread(() -> {
                try {
                    Uri uri = writePngToPictures(filename, dataUrl, "CoffeeRoast/Shared");
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("image/png");
                    send.putExtra(Intent.EXTRA_STREAM, uri);
                    send.putExtra(Intent.EXTRA_TEXT, text);
                    send.setClipData(ClipData.newUri(getContentResolver(), filename, uri));
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(send, "分享烘焙曲線"));
                } catch (Exception e) {
                    showJsMessage("❌ 分享失敗：" + safeMessage(e));
                }
            });
        }
    }

    private Uri writePngToPictures(String filename, String dataUrl, String subFolder) throws Exception {
        int comma = dataUrl == null ? -1 : dataUrl.indexOf(',');
        String payload = comma >= 0 ? dataUrl.substring(comma + 1) : dataUrl;
        if (payload == null || payload.isEmpty()) throw new Exception("圖片資料是空的");
        byte[] bytes = Base64.decode(payload, Base64.DEFAULT);

        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, filename);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + subFolder);
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
        }

        Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new Exception("Android 無法建立圖片檔");
        try {
            try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
                if (out == null) throw new Exception("Android 無法寫入圖片檔");
                out.write(bytes);
                out.flush();
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues ready = new ContentValues();
                ready.put(MediaStore.Images.Media.IS_PENDING, 0);
                getContentResolver().update(uri, ready, null, null);
            }
            return uri;
        } catch (Exception e) {
            getContentResolver().delete(uri, null, null);
            throw e;
        }
    }

    private String safeMessage(Exception e) {
        String m = e.getMessage();
        return (m == null || m.trim().isEmpty()) ? e.getClass().getSimpleName() : m;
    }

    private void showJsMessage(String message) {
        if (webView == null) return;
        String q = message.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n");
        webView.evaluateJavascript("alert('" + q + "')", null);
    }

    @Override
    public void onBackPressed() {
        // Never let Android immediately destroy the Activity.
        // Let the page close a modal, return from roast -> info, or show the exit confirmation.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            dispatchBackToWebView();
        } else {
            // Android 13+ is handled by OnBackInvokedDispatcher above.
            dispatchBackToWebView();
        }
    }
}
