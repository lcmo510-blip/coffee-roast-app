package com.coffeeroast.record;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.window.OnBackInvokedDispatcher;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // V5.4.4: keep app content out of Android system bars.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(true);
        }

        setContentView(R.layout.activity_main);

        final View root = findViewById(R.id.root);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int bottom;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                bottom = insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
            } else {
                bottom = insets.getSystemWindowInsetBottom();
            }
            // Top is already correct in V5.4.3; only protect the bottom navigation area.
            v.setPadding(0, 0, 0, bottom);
            return insets;
        });
        root.requestApplyInsets();

        webView = findViewById(R.id.webview);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);

        // V5.4.5: bridge keeps the diagnostic ping and adds only a safe native exit method.
        // Save/share functions are still intentionally not restored yet.
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidApp");

        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/index.html");

        // V5.4.6: Android 13+ predictive-back must be intercepted explicitly.
        // Without this callback, some Samsung/Android versions can finish the Activity
        // before the legacy onBackPressed() path reaches the WebView.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                () -> dispatchBackToWebView()
            );
        }
    }

    private void dispatchBackToWebView() {
        if (webView != null) {
            webView.evaluateJavascript(
                "if(window.handleAndroidBack){window.handleAndroidBack();}else if(window.requestAppExit){window.requestAppExit();}",
                null
            );
        }
    }

    public class AndroidBridge {
        @JavascriptInterface
        public String ping() {
            return "V5.4.5";
        }

        @JavascriptInterface
        public void exitApp() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    finishAndRemoveTask();
                } else {
                    finish();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        // Never let Android immediately destroy the Activity.
        // Let the page close a modal, return from roast -> info, or show the exit confirmation.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            dispatchBackToWebView();
        } else {
            // Android 13+ is handled by OnBackInvokedDispatcher above.
            dispatchBackToWebView();
        }
    }
}
