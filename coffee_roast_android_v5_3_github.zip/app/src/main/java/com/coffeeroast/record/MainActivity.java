package com.coffeeroast.record;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER = 1001;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // B01: 不讓 WebView 延伸到狀態列 / 導航列下方。
        Window window = getWindow();
        window.setStatusBarColor(0xFFFFFFFF);
        window.setNavigationBarColor(0xFFFFFFFF);
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(true);
            WindowInsetsController c = window.getInsetsController();
            if (c != null) c.setSystemBarsAppearance(
                WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS |
                WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
                WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS |
                WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
        }

        setContentView(R.layout.activity_main);
        webView = findViewById(R.id.webview);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidApp");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                startActivityForResult(i, FILE_CHOOSER);
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER && fileCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null)
                result = new Uri[]{data.getData()};
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    public class AndroidBridge {
        @JavascriptInterface public void saveBackup(String filename, String json) {
            runOnUiThread(() -> {
                try {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME, filename);
                    v.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                    v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (u == null) throw new Exception("無法建立檔案");
                    try (OutputStream os = getContentResolver().openOutputStream(u)) {
                        os.write(json.getBytes(StandardCharsets.UTF_8));
                    }
                    toastJs("alert('✅ 備份資料已儲存到 Download。')");
                } catch (Exception e) { toastJs("alert('❌ 備份失敗："+js(e.getMessage())+"')"); }
            });
        }

        @JavascriptInterface public void saveImage(String filename, String dataUrl) {
            runOnUiThread(() -> {
                try {
                    byte[] bytes = decodeDataUrl(dataUrl);
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Images.Media.DISPLAY_NAME, filename);
                    v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                    v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/CoffeeRoast");
                    Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                    if (u == null) throw new Exception("無法建立圖片");
                    try (OutputStream os = getContentResolver().openOutputStream(u)) { os.write(bytes); }
                    toastJs("alert('✅ 曲線圖片已儲存到相簿。')");
                } catch (Exception e) { toastJs("alert('❌ 儲存曲線圖片失敗："+js(e.getMessage())+"')"); }
            });
        }

        @JavascriptInterface public void shareImage(String filename, String dataUrl, String text) {
            runOnUiThread(() -> {
                try {
                    byte[] bytes = decodeDataUrl(dataUrl);
                    File dir = new File(getCacheDir(), "shared");
                    dir.mkdirs();
                    File f = new File(dir, filename);
                    try (FileOutputStream os = new FileOutputStream(f)) { os.write(bytes); }
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName()+".fileprovider", f);
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("image/png");
                    send.putExtra(Intent.EXTRA_STREAM, uri);
                    send.putExtra(Intent.EXTRA_TEXT, text);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(send, "分享烘焙曲線"));
                } catch (Exception e) { toastJs("alert('❌ 分享失敗："+js(e.getMessage())+"')"); }
            });
        }
    }

    private byte[] decodeDataUrl(String s) {
        int comma = s.indexOf(',');
        return Base64.decode(comma >= 0 ? s.substring(comma+1) : s, Base64.DEFAULT);
    }
    private String js(String s) {
        if (s == null) return "未知錯誤";
        return s.replace("\\","\\\\").replace("'","\\'");
    }
    private void toastJs(String code) { webView.evaluateJavascript(code, null); }

    @Override public void onBackPressed() {
        new AlertDialog.Builder(this)
          .setTitle("退出烘焙紀錄")
          .setMessage("確定要離開烘焙紀錄？")
          .setNegativeButton("繼續使用", null)
          .setPositiveButton("確定離開", (d, which) -> finish())
          .show();
    }
}
