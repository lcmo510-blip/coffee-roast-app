烘焙紀錄 Android V5.2

這次 A03 不再用網頁 history 攔截，而由 Android MainActivity.onBackPressed() 原生攔截。
按手機返回鍵/返回手勢會先顯示退出確認。

建置：
1. 用 Android Studio 開啟此資料夾。
2. 等 Gradle Sync 完成。
3. Build > Build APK(s)。
4. APK 通常位於 app/build/outputs/apk/debug/app-debug.apk。
