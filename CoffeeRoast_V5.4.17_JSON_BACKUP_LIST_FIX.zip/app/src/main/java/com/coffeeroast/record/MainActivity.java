package com.coffeeroast.record;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ContentValues;
import android.database.Cursor;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.os.Build;
import android.os.Bundle;
import android.window.OnBackInvokedDispatcher;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int PICK_BACKUP = 5410;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) getWindow().setDecorFitsSystemWindows(true);
        setContentView(R.layout.activity_main);
        final View root=findViewById(R.id.root);
        root.setOnApplyWindowInsetsListener((v,insets)->{int bottom=Build.VERSION.SDK_INT>=Build.VERSION_CODES.R?insets.getInsets(WindowInsets.Type.navigationBars()).bottom:insets.getSystemWindowInsetBottom();v.setPadding(0,0,0,bottom);return insets;});
        root.requestApplyInsets();
        webView=findViewById(R.id.webview); WebSettings settings=webView.getSettings(); settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
        webView.addJavascriptInterface(new AndroidBridge(),"AndroidApp"); webView.setWebViewClient(new WebViewClient()); webView.loadUrl("file:///android_asset/index.html");
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.TIRAMISU)getOnBackInvokedDispatcher().registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT,()->dispatchBackToWebView());
    }
    private void dispatchBackToWebView(){if(webView!=null)webView.evaluateJavascript("if(window.handleAndroidBack){window.handleAndroidBack();}else if(window.requestAppExit){window.requestAppExit();}",null);}
    private void js(String code){runOnUiThread(()->{if(webView!=null)webView.evaluateJavascript(code,null);});}
    private String jq(String s){return JSONObject.quote(s==null?"":s);}

    public class AndroidBridge {
        @JavascriptInterface public String ping(){return "V5.4.17";}
        @JavascriptInterface public void exitApp(){runOnUiThread(()->{if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP)finishAndRemoveTask();else finish();});}

        @JavascriptInterface public void saveImageAsync(String filename,String dataUrl){
            new Thread(()->{try{writePngToPictures(filename,dataUrl,"CoffeeRoast");js("window.onCurveSaveResult&&window.onCurveSaveResult(true,'')");}catch(Exception e){js("window.onCurveSaveResult&&window.onCurveSaveResult(false,"+jq(safeMessage(e))+")");}}).start();
        }
        @JavascriptInterface public void shareImageAsync(String filename,String dataUrl,String text){
            new Thread(()->{try{final Uri uri=writePngToPictures(filename,dataUrl,"CoffeeRoast/Shared");runOnUiThread(()->{try{Intent send=new Intent(Intent.ACTION_SEND);send.setType("image/png");send.putExtra(Intent.EXTRA_STREAM,uri);send.putExtra(Intent.EXTRA_TEXT,text);send.setClipData(ClipData.newUri(getContentResolver(),filename,uri));send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(send,"分享烘焙曲線"));js("window.onCurveShareResult&&window.onCurveShareResult(true,'')");}catch(Exception e){js("window.onCurveShareResult&&window.onCurveShareResult(false,"+jq(safeMessage(e))+")");}});}catch(Exception e){js("window.onCurveShareResult&&window.onCurveShareResult(false,"+jq(safeMessage(e))+")");}}).start();
        }
        @JavascriptInterface public void saveHistoryBackup(String filename,String text){
            runOnUiThread(()->Toast.makeText(MainActivity.this,"正在備份歷史烘焙資料…",Toast.LENGTH_SHORT).show());
            new Thread(()->{
                try{
                    if(text==null||text.trim().isEmpty()) throw new Exception("備份資料是空的");
                    writeTextToDownloads(filename,text,"application/json");
                    runOnUiThread(()->Toast.makeText(MainActivity.this,"歷史資料備份完成",Toast.LENGTH_SHORT).show());
                    js("window.onHistoryBackupResult&&window.onHistoryBackupResult(true,"+jq(filename)+")");
                }catch(Exception e){
                    String msg=safeMessage(e);
                    runOnUiThread(()->Toast.makeText(MainActivity.this,"備份失敗："+msg,Toast.LENGTH_LONG).show());
                    js("window.onHistoryBackupResult&&window.onHistoryBackupResult(false,"+jq(msg)+")");
                }
            }).start();
        }
        @JavascriptInterface public void saveCsvExport(String filename,String text){
            new Thread(()->{
                try{
                    writeTextToDownloads(filename,text,"text/csv");
                    js("window.onCsvExportResult&&window.onCsvExportResult(true,"+jq(filename)+")");
                }catch(Exception e){
                    js("window.onCsvExportResult&&window.onCsvExportResult(false,"+jq(safeMessage(e))+")");
                }
            }).start();
        }
        @JavascriptInterface public void pickBackup(){
            runOnUiThread(()->showJsonBackupList());
        }
    }

    private void showJsonBackupList(){
        final ArrayList<String> names=new ArrayList<>();
        final ArrayList<Uri> uris=new ArrayList<>();
        try{
            Uri collection=Build.VERSION.SDK_INT>=Build.VERSION_CODES.Q
                    ? MediaStore.Downloads.EXTERNAL_CONTENT_URI
                    : MediaStore.Files.getContentUri("external");
            String[] projection=new String[]{MediaStore.MediaColumns._ID,MediaStore.MediaColumns.DISPLAY_NAME};
            String selection=MediaStore.MediaColumns.DISPLAY_NAME+" LIKE ?";
            String[] args=new String[]{"%.json"};
            String sort=MediaStore.MediaColumns.DATE_MODIFIED+" DESC";
            try(Cursor c=getContentResolver().query(collection,projection,selection,args,sort)){
                if(c!=null){
                    int idCol=c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID);
                    int nameCol=c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME);
                    while(c.moveToNext()){
                        String name=c.getString(nameCol);
                        if(name==null||!name.toLowerCase().endsWith(".json"))continue;
                        long id=c.getLong(idCol);
                        names.add(name);
                        uris.add(Uri.withAppendedPath(collection,String.valueOf(id)));
                    }
                }
            }
        }catch(Exception e){
            Toast.makeText(this,"讀取 JSON 清單失敗："+safeMessage(e),Toast.LENGTH_LONG).show();
        }
        if(names.isEmpty()){
            new AlertDialog.Builder(this)
                    .setTitle("選擇 JSON 備份")
                    .setMessage("找不到 JSON 備份檔。")
                    .setPositiveButton("確定",null)
                    .show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("選擇 JSON 備份")
                .setItems(names.toArray(new String[0]),(d,which)->restoreBackupFromUri(uris.get(which)))
                .setNegativeButton("取消",null)
                .show();
    }

    private void restoreBackupFromUri(Uri uri){
        try(InputStream in=getContentResolver().openInputStream(uri);ByteArrayOutputStream out=new ByteArrayOutputStream()){
            if(in==null)throw new Exception("無法開啟備份檔");
            byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);
            String json=out.toString("UTF-8");
            js("window.onBackupPicked&&window.onBackupPicked("+jq(json)+")");
        }catch(Exception e){js("alert('❌ 還原失敗：'+"+jq(safeMessage(e))+")");}
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_BACKUP){
            if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
                restoreBackupFromUri(data.getData());
            }
            return;
        }
    }

    private Uri writePngToPictures(String filename,String dataUrl,String subFolder)throws Exception{int comma=dataUrl==null?-1:dataUrl.indexOf(',');String payload=comma>=0?dataUrl.substring(comma+1):dataUrl;if(payload==null||payload.isEmpty())throw new Exception("圖片資料是空的");byte[] bytes=Base64.decode(payload,Base64.DEFAULT);ContentValues values=new ContentValues();values.put(MediaStore.Images.Media.DISPLAY_NAME,filename);values.put(MediaStore.Images.Media.MIME_TYPE,"image/png");if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.Q){values.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/"+subFolder);values.put(MediaStore.Images.Media.IS_PENDING,1);}Uri uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);if(uri==null)throw new Exception("Android 無法建立圖片檔");try{try(OutputStream out=getContentResolver().openOutputStream(uri,"w")){if(out==null)throw new Exception("Android 無法寫入圖片檔");out.write(bytes);out.flush();}if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.Q){ContentValues ready=new ContentValues();ready.put(MediaStore.Images.Media.IS_PENDING,0);getContentResolver().update(uri,ready,null,null);}return uri;}catch(Exception e){getContentResolver().delete(uri,null,null);throw e;}}
    private Uri writeTextToDownloads(String filename,String text,String mime)throws Exception{
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.Q){
            ContentValues v=new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME,filename);
            v.put(MediaStore.Downloads.MIME_TYPE,mime);
            v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/CoffeeRoast/");
            v.put(MediaStore.Downloads.IS_PENDING,1);
            Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
            if(uri==null)throw new Exception("Android 無法建立下載檔案");
            try{
                try(OutputStream out=getContentResolver().openOutputStream(uri,"w")){
                    if(out==null)throw new Exception("Android 無法開啟檔案寫入");
                    out.write(text.getBytes(StandardCharsets.UTF_8));out.flush();
                }
                ContentValues ready=new ContentValues();ready.put(MediaStore.Downloads.IS_PENDING,0);
                getContentResolver().update(uri,ready,null,null);
                return uri;
            }catch(Exception e){getContentResolver().delete(uri,null,null);throw e;}
        }
        File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"CoffeeRoast");
        if(!dir.exists()&&!dir.mkdirs())throw new Exception("無法建立 CoffeeRoast 資料夾");
        File f=new File(dir,filename);
        try(FileOutputStream out=new FileOutputStream(f)){out.write(text.getBytes(StandardCharsets.UTF_8));out.flush();}
        return Uri.fromFile(f);
    }
    private String safeMessage(Exception e){String m=e.getMessage();return(m==null||m.trim().isEmpty())?e.getClass().getSimpleName():m;}
    @Override public void onBackPressed(){dispatchBackToWebView();}
}
