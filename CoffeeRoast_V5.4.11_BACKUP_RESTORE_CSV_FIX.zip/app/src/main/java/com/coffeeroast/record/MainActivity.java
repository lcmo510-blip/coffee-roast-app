package com.coffeeroast.record;

import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.os.Build;
import android.os.Bundle;
import android.window.OnBackInvokedDispatcher;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int PICK_BACKUP = 5410;
    private static final int CREATE_TEXT_FILE = 5411;
    private String pendingText = null;
    private String pendingFilename = null;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) getWindow().setDecorFitsSystemWindows(true);
        setContentView(R.layout.activity_main);
        final View root=findViewById(R.id.root);
        root.setOnApplyWindowInsetsListener((v,insets)->{int bottom=Build.VERSION.SDK_INT>=Build.VERSION_CODES.R?insets.getInsets(WindowInsets.Type.navigationBars()).bottom:insets.getSystemWindowInsetBottom();v.setPadding(0,0,0,bottom);return insets;});
        root.requestApplyInsets();
        webView=findViewById(R.id.webview); WebSettings settings=webView.getSettings(); settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
        webView.addJavascriptInterface(new AndroidBridge(),"AndroidApp"); webView.setWebViewClient(new WebViewClient()); webView.loadUrl("file:///android_asset/index.html");
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.TIRAMISU)getOnBackInvokedDispatcher().registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT,()->dispatchBackToWebView());
    }
    private void dispatchBackToWebView(){if(webView!=null)webView.evaluateJavascript("if(window.handleAndroidBack){window.handleAndroidBack();}else if(window.requestAppExit){window.requestAppExit();}",null);}
    private void js(String code){runOnUiThread(()->{if(webView!=null)webView.evaluateJavascript(code,null);});}
    private String jq(String s){return JSONObject.quote(s==null?"":s);}

    public class AndroidBridge {
        @JavascriptInterface public String ping(){return "V5.4.11";}
        @JavascriptInterface public void exitApp(){runOnUiThread(()->{if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP)finishAndRemoveTask();else finish();});}

        @JavascriptInterface public void saveImageAsync(String filename,String dataUrl){
            new Thread(()->{try{writePngToPictures(filename,dataUrl,"CoffeeRoast");js("window.onCurveSaveResult&&window.onCurveSaveResult(true,'')");}catch(Exception e){js("window.onCurveSaveResult&&window.onCurveSaveResult(false,"+jq(safeMessage(e))+")");}}).start();
        }
        @JavascriptInterface public void shareImageAsync(String filename,String dataUrl,String text){
            new Thread(()->{try{final Uri uri=writePngToPictures(filename,dataUrl,"CoffeeRoast/Shared");runOnUiThread(()->{try{Intent send=new Intent(Intent.ACTION_SEND);send.setType("image/png");send.putExtra(Intent.EXTRA_STREAM,uri);send.putExtra(Intent.EXTRA_TEXT,text);send.setClipData(ClipData.newUri(getContentResolver(),filename,uri));send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(send,"分享烘焙曲線"));js("window.onCurveShareResult&&window.onCurveShareResult(true,'')");}catch(Exception e){js("window.onCurveShareResult&&window.onCurveShareResult(false,"+jq(safeMessage(e))+")");}});}catch(Exception e){js("window.onCurveShareResult&&window.onCurveShareResult(false,"+jq(safeMessage(e))+")");}}).start();
        }
        @JavascriptInterface public void saveTextFile(String filename,String text,String mime){
            runOnUiThread(()->{
                try{
                    pendingText=text; pendingFilename=filename;
                    Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType((mime==null||mime.isEmpty())?"text/plain":mime);
                    i.putExtra(Intent.EXTRA_TITLE,filename);
                    startActivityForResult(i,CREATE_TEXT_FILE);
                }catch(Exception e){
                    pendingText=null; pendingFilename=null;
                    js("window.onNativeFileSaved&&window.onNativeFileSaved(false,"+jq(safeMessage(e))+")");
                }
            });
        }
        @JavascriptInterface public void pickBackup(){runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");startActivityForResult(i,PICK_BACKUP);});}
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_BACKUP){
            if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
                try(InputStream in=getContentResolver().openInputStream(data.getData());ByteArrayOutputStream out=new ByteArrayOutputStream()){
                    byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);
                    String json=out.toString("UTF-8");
                    js("window.onBackupPicked&&window.onBackupPicked("+jq(json)+")");
                }catch(Exception e){js("alert('❌ 還原失敗：'+"+jq(safeMessage(e))+")");}
            }
            return;
        }
        if(requestCode==CREATE_TEXT_FILE){
            String name=pendingFilename; String text=pendingText;
            pendingFilename=null; pendingText=null;
            if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
                try(OutputStream out=getContentResolver().openOutputStream(data.getData(),"w")){
                    if(out==null)throw new Exception("無法開啟儲存檔案");
                    out.write((text==null?"":text).getBytes(StandardCharsets.UTF_8));out.flush();
                    js("window.onNativeFileSaved&&window.onNativeFileSaved(true,"+jq((name==null?"檔案":name)+" 儲存完成")+")");
                }catch(Exception e){js("window.onNativeFileSaved&&window.onNativeFileSaved(false,"+jq(safeMessage(e))+")");}
            }else{
                js("window.onNativeFileSaved&&window.onNativeFileSaved(false,'已取消儲存')");
            }
        }
    }

    private Uri writePngToPictures(String filename,String dataUrl,String subFolder)throws Exception{int comma=dataUrl==null?-1:dataUrl.indexOf(',');String payload=comma>=0?dataUrl.substring(comma+1):dataUrl;if(payload==null||payload.isEmpty())throw new Exception("圖片資料是空的");byte[] bytes=Base64.decode(payload,Base64.DEFAULT);ContentValues values=new ContentValues();values.put(MediaStore.Images.Media.DISPLAY_NAME,filename);values.put(MediaStore.Images.Media.MIME_TYPE,"image/png");if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.Q){values.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/"+subFolder);values.put(MediaStore.Images.Media.IS_PENDING,1);}Uri uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);if(uri==null)throw new Exception("Android 無法建立圖片檔");try{try(OutputStream out=getContentResolver().openOutputStream(uri,"w")){if(out==null)throw new Exception("Android 無法寫入圖片檔");out.write(bytes);out.flush();}if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.Q){ContentValues ready=new ContentValues();ready.put(MediaStore.Images.Media.IS_PENDING,0);getContentResolver().update(uri,ready,null,null);}return uri;}catch(Exception e){getContentResolver().delete(uri,null,null);throw e;}}
    private Uri writeTextToDownloads(String filename,String text,String mime)throws Exception{ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,filename);v.put(MediaStore.Downloads.MIME_TYPE,mime);if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.Q)v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/CoffeeRoast");Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(uri==null)throw new Exception("無法建立檔案");try(OutputStream out=getContentResolver().openOutputStream(uri,"w")){if(out==null)throw new Exception("無法寫入檔案");out.write(text.getBytes(StandardCharsets.UTF_8));out.flush();}return uri;}
    private String safeMessage(Exception e){String m=e.getMessage();return(m==null||m.trim().isEmpty())?e.getClass().getSimpleName():m;}
    @Override public void onBackPressed(){dispatchBackToWebView();}
}
