package com.coffeeroast.record;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(48, 48, 48, 48);
        root.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("V5.4.2 啟動成功");
        title.setTextSize(28);
        title.setTextColor(Color.rgb(30, 90, 55));
        title.setGravity(Gravity.CENTER);

        TextView note = new TextView(this);
        note.setText("這是最小啟動診斷版。\n如果你看得到這個畫面，代表 Android Activity / Manifest / Theme 基本正常，問題就在 WebView 或原本的啟動程式。");
        note.setTextSize(17);
        note.setTextColor(Color.DKGRAY);
        note.setGravity(Gravity.CENTER);
        note.setPadding(0, 36, 0, 0);

        root.addView(title);
        root.addView(note);
        setContentView(root);
    }
}
